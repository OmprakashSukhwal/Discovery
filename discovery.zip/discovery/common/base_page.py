from robot.libraries.BuiltIn import BuiltIn
from robot.libraries.DateTime import datetime
from Selenium2Library import Selenium2Library
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.remote.command import Command
from selenium.common.exceptions import *
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from BaseLocators import BaseLocators as Locators


class BasePage():
    def __init__(self):
        self.session = Selenium2Library(run_on_failure='Nothing')
        self.builtin = BuiltIn()
        self.datetime = datetime
        self.set_browser_settings()

    def screenshot(self):

        self.session.capture_page_screenshot()

    def set_browser_settings(self, browser='gc', timeout=10, implicit_wait=10, speed=0.1, run_on_failure='screenshot',
                             screenshot_root_directory=None):
        self.browser = browser
        self.selenium_timeout = timeout
        self.implicit_wait = implicit_wait
        self.selenium_speed = speed
        self.run_on_failure = run_on_failure
        self.screenshot_directory = screenshot_root_directory

    def close_browser_window(self):
        self.session.close_browser()

    def close_browser_all_windows(self):
        self.session.close_all_browsers()

    def open_url(self, url, alias=None):
        self.session.open_browser(url, browser=self.browser, alias=alias)
        self.session.maximize_browser_window()
        self._browser_settings()

    def _browser_settings(self):
        self.session.set_selenium_timeout(self.selenium_timeout)
        self.session.set_browser_implicit_wait(self.implicit_wait)
        self.session.set_selenium_speed(self.selenium_speed)
        self.session.register_keyword_to_run_on_failure(self.run_on_failure)
        # self.session.set_screenshot_directory(self.screenshot_directory)

    def _open_browser_window(self, server, protocol='https', port=443, alias=None):
        url = "%s://%s:%s" % (protocol, server, port)
        self.session.open_browser(url, browser=self.browser, alias=alias)
        self.session.maximize_browser_window()
        self._browser_settings()

    def _click(self):
        """
            Overriding Selenium.WebElement click method for scroll issue
            inherent to TSPS.

            TSPS has a floating product header and web elements tends to hide
            under it. This method is to bring such web elements into the
            viewport so that the elements can be interacted with.

        """
        for i in xrange(2):
            try:
                self._execute(Command.CLICK_ELEMENT)
                break
            except:
                if i == 0:
                    print "Bringing Web Element into the center of the viewport"
                    self.parent.execute_script('arguments[0].scrollIntoView({block:"center", inline: "nearest"});',
                                               self)
                else:
                    raise

    WebElement.click = _click

    def click_element(self, locator):
        """
            Click element identified by `locator`.

            Key attributes for arbitrary elements are `id` and `name`. See
            `introduction` for details about locating elements.

            @param locator: identifier to the elements along with locator
                            strategy to be used
            @type locator: String

        """
        for i in xrange(3):
            try:
                self.session.wait_until_element_is_visible(locator)
                self.session.click_element(locator)
                break
            except:
                if i in xrange(2):
                    self.builtin.sleep(2)
                else:
                    raise

    def control_click_element(self, locator):
        """
            Click element identified by `locator`.

            Key attributes for arbitrary elements are `id` and `name`. See
            `introduction` for details about locating elements.

            @param locator: identifier to the elements along with locator
                            strategy to be used
            @type locator: String

        """
        ActionChains(self.session._current_browser()).key_down(Keys.CONTROL).perform()
        self.click_element(locator)
        ActionChains(self.session._current_browser()).key_up(Keys.CONTROL).perform()

    def input_text(self, locator, text):
        for _ in xrange(3):
            try:
                self.session.wait_until_element_is_visible(locator)
                self.session.input_text(locator, text)
                break
            except:
                self.session.wait_until_element_is_visible(locator)

    def scroll_down(self, pixels):
        self._scrollBy(0, pixels)

    def scroll_up(self, pixels):
        self._scrollBy(pixels, 0)

    def _scrollBy(self, xcord, ycord):
        self.session.execute_javascript('window.scrollBy(%s,%s)' % (xcord, ycord))

    def reload_page(self):
        self.session.reload_page()

    def remove_pendo_screen(self):
        self.session.wait_until_element_is_visible(Locators.pendo_icon)
        self.session.execute_javascript('return pendo.onGuideDismissed()')

    def switch_to_another_window(self, window='TrueSight'):
        self.session.select_window(window)

    def close_success_message(self):
        """
        This Keyword is applicable for all Pages
        To close the notification for success message
        """
        self.click_element(Locators.success_message_close)

    def close_error_message(self):
        """
        This Keyword is applicable for all Pages
        To close the notification for error message
        """
        self.click_element(Locators.error_message_close)

    def close_attention_message(self):
        """
        This Keyword is applicable for all Pages
        To close the notification for attention message
        """
        self.click_element(Locators.attention_message_close)

    def verify_popup_message(self, message):
        self.session.wait_until_element_is_visible(Locators.popup_message.replace('MESSAGE', message))

    def verify_inline_ui_message(self, message):
        self.session.wait_until_element_is_visible(Locators.inline_ui_message.replace('MESSAGE', message))

    def verify_windows_title(self, message):
        """
        This Keyword is applicable for all Pages
        To verify title of the current window
        """
        self.session.title_should_be(message)