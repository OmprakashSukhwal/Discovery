from locators import locators
from global_lib import Global
import csv


class DiscoveryKeywords(Global):

    def go_to_discovery_home_page(self):
        self.open_browser("https://go.discovery.com/")

    def go_to_footer(self):
        self.click_element(locators.footer)

    def add_all_search_results_to_favorite(self):
        self.browser.wait_until_page_contains_element(locators.search_results, 30)
        count = self.browser.get_matching_xpath_count(locators.search_results)
        print count
        search_result_shows = []
        for index in range(1, int(count) + 1):
            name = self.browser.get_element_attribute(locators.search_result.replace('%s', str(index)), "href")
            name = name.split('/tv-shows/')[1]
            search_result_shows.append(name)
            self.click_element(locators.search_result.replace('%s', str(index)))
            try:
                self.add_to_favorite()
                self.browser.wait_until_page_contains_element(locators.remove_from_fav, 30)
            except:
                pass
            self.click_element(locators.search_icon)
            self.click_element(locators.view_all_results)

        print search_result_shows
        return search_result_shows

    def add_to_favorite(self):
        self.click_element(locators.add_to_fav)

    def get_favorite_shows(self):
        self.browser.wait_until_page_contains_element(locators.favorite_shows, 30)
        count = self.browser.get_matching_xpath_count(locators.favorite_shows)
        print count
        favorite_shows = []
        for index in range(1, int(count) + 1):
            name = self.browser.get_element_attribute(locators.favorite_show.replace('%s', str(index)), "href")
            name = name.split('/tv-shows/')[1]
            favorite_shows.append(name)
        print favorite_shows
        return favorite_shows

    def search_show(self, show_keyword):
        self.click_element(locators.search_icon)
        self.input_text(locators.search_input, show_keyword)
        self.click_element(locators.view_all_results)

    def go_to_my_videos(self):
        self.click_element(locators.menu_link)
        self.click_element(locators.my_videos)

    def move_to_popular_shows_dot_pager(self):
        self.click_element(locators.popular_show_dot_pager)

    def go_to_last_popular_show(self):
        count = self.browser.get_matching_xpath_count(locators.all_popular_shows_explore_btn)
        for i in range(int(count)):
            try:
                self.click_element(locators.right_arrow)
            except:
                break

    def explore_the_show(self):
        count = self.browser.get_matching_xpath_count(locators.all_popular_shows_explore_btn)
        self.click_element(locators.explore_btn.replace("%s",count))

    def show_more_episode(self):
        while True:
            try:
                self.click_element(locators.show_more_button)
            except:
                break

    def get_all_episodes_title_and_time(self):
        count = self.browser.get_matching_xpath_count(locators.episodes)
        titles = []
        duration = []
        title_duration_dict = {}
        for index in range(1,int(count)+1):
            titles.append(self.browser.get_text(locators.episode_titles.replace('%s',str(index))))
            duration.append(self.browser.get_text(locators.episode_durations.replace("%s", str(index))))
        title_duration_dict.update(zip(titles,duration))
        return title_duration_dict

    def export_title_duration_to_file(self, title_duration_dict):
        with open('output.csv', 'wb') as output:
            writer = csv.writer(output)
            for key, value in title_duration_dict.iteritems():
                writer.writerow([key, value])

    def get_title_duration_from_file(self):
        data = {}
        with open('output.csv', 'rt') as output:
            reader = csv.reader(output)
            for row in reader:
                data[row[0]] = row[1]
        return data

    def click_shows(self):
        self.click_element(locators.shows)

    def click_see_all_shows(self):
        self.click_shows()
        self.click_element(locators.see_all_shows)
